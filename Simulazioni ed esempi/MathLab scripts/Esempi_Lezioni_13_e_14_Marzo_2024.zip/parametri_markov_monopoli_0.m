clear; close all;

% Parametri della rete di Markov Gioco Monopoli Ridotto (Pago pedaggio se
% in prigione)

A=zeros(7,7);
A(1,7)=0.5;
A(2,1)=0.5;A(2,7)=0.5;
A(3,1)=0.5;A(3,2)=0.5;A(3,5)=0.5;A(3,6)=0.5;
A(4,2)=0.5;A(4,3)=0.5;
A(5,3)=0.5;A(5,4)=0.5;
A(6,4)=0.5;A(6,5)=0.5;
A(7,6)=0.5;

% Parto dal via

x0=zeros(7,1);
x0(1)=1;

% Vettore Pedaggi

P=[0;15;0;35;40;48;60];

% Numero lanci

nlanci=1000;