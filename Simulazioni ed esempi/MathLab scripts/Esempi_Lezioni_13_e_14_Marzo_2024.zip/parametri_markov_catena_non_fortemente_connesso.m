clear; close all;

% Parametri della rete di Markov Gioco Monopoli Ridotto (Lancio dadi se
% in prigione con probabilita' q e con probabilita' 1-q pago pedaggio)


A=zeros(5,5);
A(1,1)=0.5;
A(1,2)=0.5;
A(2,1)=0.5;
A(3,2)=0.5;
A(3,5)=1;
A(4,3)=1;
A(5,4)=1;

% Stato iniziale casuale

x0=rand(5,1);
x0=x0/sum(x0);

% Stato iniziale particolare

% x0=[0;0;1/3;1/3;1/3];

% Numero lanci

nlanci=10000;

% Eseguo lo start del foglio simulink dall'interprete comandi di Matlab

risultato=sim('catena_non_fortemente_connesso');

% Rappresento graficamente una porzione del terzo stato

% stem(risultato.tout(900:end),risultato.stato(900:end,3),LineWidth=1.5);
% grid;

x_erg=sum(risultato.stato,1)/nlanci;  % Media temporale