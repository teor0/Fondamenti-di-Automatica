clear; close all;

% Parametri della rete di Markov Gioco Monopoli Ridotto (Lancio dadi se
% in prigione con probabilita' q e con probabilita' 1-q pago pedaggio)

q=0.6;

A=zeros(8,8);
A(1,8)=0.5;
A(2,1)=0.5;A(2,8)=0.5;
A(3,1)=0.5;A(3,2)=0.5;
A(4,4)=0.5*q;A(4,6)=0.5;A(4,7)=0.5;
A(5,2)=0.5;A(5,3)=0.5;A(5,4)=0.5-0.25*q;
A(6,3)=0.5;A(6,4)=0.5-0.25*q;A(6,5)=0.5;
A(7,5)=0.5;A(7,6)=0.5;
A(8,7)=0.5;

% Parto dal via

x0=zeros(8,1);
x0(1)=1;

% Vettore Pedaggi

P=[0;15;0;0;35;40;48;60];

% Numero lanci

nlanci=1000;